package at.fhooe.mc.android.findbuddy;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by David on 19.12.17.
 */

public class ProfileFragment extends Fragment{

    private TextView textView;

    public ProfileFragment(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.profile_fragment, container, false);

        textView = (TextView)rootView.findViewById(R.id.profile_fragment_text);

        String title = "Profile";
        textView.setText(title);

        return rootView;
    }

}
