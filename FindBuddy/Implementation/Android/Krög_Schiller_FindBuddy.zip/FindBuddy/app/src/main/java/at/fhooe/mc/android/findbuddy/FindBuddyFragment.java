package at.fhooe.mc.android.findbuddy;

import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationListener;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMyLocationButtonClickListener;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import android.Manifest;

import java.io.UTFDataFormatException;
import java.security.Provider;
import java.util.ArrayList;


import at.fhooe.mc.android.findbuddy.Entities.MyActivity;

/**
 * Created by David on 19.12.17.
 */

public class FindBuddyFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMapClickListener, LocationListener, OnMyLocationButtonClickListener, ActivityCompat.OnRequestPermissionsResultCallback, View.OnClickListener{

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private static final long MIN_TIME = 400;
    private static final float MIN_DISTANCE = 1000;

    ArrayList<MyActivity> activityList;

    private MapView mapView;
    private GoogleMap googleMap;
    private LocationManager locationManager;
    private Location myLocation;
    private boolean addMode= false;
    private Marker tapped = null;

    FloatingActionButton addActivityButton;
    FloatingActionButton cancelButton;



    public FindBuddyFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.findbuddy_fragment, container, false);

        activityList = (ArrayList<MyActivity>) getArguments().getSerializable("ACTIVITY_LIST");

        mapView = rootView.findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);
        mapView.onResume(); //to display map immediately

        try{
            MapsInitializer.initialize(this.getActivity().getApplicationContext());
        } catch (Exception e) {
            e.printStackTrace();
        }

        mapView.getMapAsync(this);

        if (ActivityCompat.checkSelfPermission(getContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else if (googleMap != null) {
            // Access to the location has been granted to the app.
            locationManager = (LocationManager) getContext().getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, MIN_TIME, MIN_DISTANCE, this);
        }

        addActivityButton  = rootView.findViewById(R.id.addButton);
        cancelButton  = rootView.findViewById(R.id.cancelButton);
        addActivityButton.setOnClickListener(this);
        cancelButton.setOnClickListener(this);

        return rootView;
    }




    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    @Override
    public void onMapReady(GoogleMap map) {
        googleMap = map;

        googleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        googleMap.setBuildingsEnabled(true);
        googleMap.getUiSettings().setTiltGesturesEnabled(false);
        googleMap.getUiSettings().setZoomControlsEnabled(false);
        googleMap.getUiSettings().setMyLocationButtonEnabled(true);
        googleMap.getUiSettings().setMapToolbarEnabled(false);
        googleMap.getUiSettings().setCompassEnabled(true);
        googleMap.setOnMyLocationButtonClickListener(this);
        enableMyLocation();

        googleMap.setOnMapClickListener(this);
        for (MyActivity activity : activityList) {
            Marker marker = googleMap.addMarker(new MarkerOptions()
                    .position(new LatLng(activity.getLatitude(), activity.getLongitude()))
                    .title(activity.getName())
                    .snippet(activity.getCategory()));
        }


    }

    private void enableMyLocation() {
        if (ActivityCompat.checkSelfPermission(getContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else if (googleMap != null) {
            // Access to the location has been granted to the app.
            googleMap.setMyLocationEnabled(true);
        }
    }



    @Override
    public void onMapClick(LatLng latLng) {
        if(addMode){
            if (tapped != null) {
                tapped.remove();
                tapped = null;
            }
            if (tapped == null) {
                tapped = googleMap.addMarker(new MarkerOptions().position(latLng).title("LongTap").snippet("Geht dahi!"));
                tapped.setDraggable(true);
            }
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.addButton:
                if(addMode){
                    if(tapped!=null) {
                        saveLocation();
                        addMode = false;
                        cancelButton.setVisibility(View.INVISIBLE);
                    }else {
                        Toast.makeText(this.getContext(), "Standort auswählen", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this.getContext(), "Standort auswählen", Toast.LENGTH_SHORT).show();
                    addMode = true;
                    cancelButton.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.cancelButton:
                addMode = false;
                cancelButton.setVisibility(View.INVISIBLE);
                if(tapped!=null){
                    tapped.remove();
                    tapped = null;
                }
                break;
        }

    }

    private void saveLocation() {
        Intent i = new Intent(this.getContext(), AddActivity.class);
        i.putExtra("POSITION", tapped.getPosition());
        if(tapped!=null){
            tapped.remove();
            tapped = null;
        }
        startActivity(i);
    }

    @Override
    public boolean onMyLocationButtonClick() {
        return false;
    }

    @Override
    public void onLocationChanged(Location location) {
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
}
