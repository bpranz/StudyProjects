package at.fhooe.mc.android.findbuddy;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import at.fhooe.mc.android.findbuddy.Entities.MyActivity;
import at.fhooe.mc.android.findbuddy.Helper.ActivityAdapter;

/**
 * Created by David on 19.12.17.
 */

public class ActivityFragment extends Fragment {

    ArrayList<MyActivity> activityList;
    RecyclerView activityRecyclerView;
    RecyclerView.LayoutManager activityLayoutManager;

    public ActivityFragment(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.activity_fragment, container, false);

        activityList = (ArrayList<MyActivity>) getArguments().getSerializable("ACTIVITY_LIST");
        activityRecyclerView = rootView.findViewById(R.id.activityRecyclerView);

        activityLayoutManager = new LinearLayoutManager(rootView.getContext());
        activityRecyclerView.setLayoutManager(activityLayoutManager);

        ActivityAdapter activityAdapter = new ActivityAdapter(activityList);
        activityRecyclerView.setAdapter(activityAdapter);

        return rootView;
    }
}
